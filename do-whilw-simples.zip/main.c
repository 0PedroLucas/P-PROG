#include <stdio.h>

int main(){
    int nmr;
    do{
    printf("\n""Digite um numero: ");
    scanf("%i", &nmr);
    
    if(nmr!=0){
        printf("\nErrou! tente novamente!");
    }
    }
    
    while(nmr != 0);
    printf("\nEncerrando programa!");
}